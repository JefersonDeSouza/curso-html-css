<figure class="highlight">
	<img id="Banner" class="highlight__image" src="http://www.lorempixel.com/1200/250" alt="">
	<figcaption class="highlight__title">Acelerando no mundo da Audi</figcaption>
	

	<!-- CARROSSEL COM JQUEY -->
	<!--
	<div id="content" class="carrossels">
		<div id="carrossel" class="carrossel">
			<ul>
				<li>
					<img class="carrossel__image" src="img/img11.jpg" alt="Primeira Imagem" title="1"/>
				</li>
				<li>
					<img class="carrossel__image" src="img/img12.jpg" alt="Segunda Imagem" title="2"/>
				</li>
				<li>
					<img class="carrossel__image" src="img/img13.png" alt="Terceira Imagem" title="3"/>
				</li>
				<li>
					<img class="carrossel__image" src="img/img14.jpg" alt="Quarta Imagem" title="4"/>
				</li>
				<li>
					<img class="carrossel__image" src="img/img5.png" alt="Quinta Imagem" title="5"/>
				</li>
			</ul>
		</div>
		<nav id="highlight__navegation">
			<a href="#" class="prev" title="Anterior">Anterior</a>
			<a href="#" class="next" title="Próximo">Próximo</a>
		</nav>
	</div>-->
</figure>