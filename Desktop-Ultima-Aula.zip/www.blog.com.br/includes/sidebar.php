<section role="sidebar">
	<aside>
		<dl class="sidebar">
			<dt class="sidebar__title">Posts</dt>
			<dd class="sidebar__link"><a href="#">Título do Post 1</a></dd>
			<dd class="sidebar__link"><a href="#">Título do Post 2</a></dd>
			<dd class="sidebar__link"><a href="#">Título do Post 3</a></dd>
			<dd class="sidebar__link"><a href="#">Título do Post 4</a></dd>
			<dd class="sidebar__link"><a href="#">Título do Post 5</a></dd>
		</dl>
	</aside>
</section>