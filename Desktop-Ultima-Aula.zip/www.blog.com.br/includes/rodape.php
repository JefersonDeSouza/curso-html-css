<footer class="site-footer clearfix">
	<p class="site-footer__copyright">&copy; 2016-Audi Automóveis-Todos os direitos Reservados</p>	
	<ul class="site-footer__social social">
		<li class="social__icon social__icon--fb"><a href="#">Facebook</a></li>
		<li class="social__icon social__icon--tw"><a href="#">Twitter</a></li>
		<li class="social__icon social__icon--lk"><a href="#">Linkdin</a></li>
	</ul>
</footer>