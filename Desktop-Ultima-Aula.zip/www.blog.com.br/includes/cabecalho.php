<header class="site-heeader">
	<h1 class="site-header__brand"><a href="#">Audi</a></h1>
	<nav class="site-header__navigation">
		<ul class="menu clearfix">
			<li class="menu__item menu__item--current"><a href="item1.html">Home</a></li>
			<li class="menu__item"><a href="item2.html">Cadastra-se</a></li>
			<li class="menu__item"><a href="item3.html">Modelos</a></li>
			<li class="menu__item"><a href="item4.html">Financiamentos</a></li>
			<li class="menu__item"><a href="item5.html">Serviços</a></li>
			<li class="menu__item"><a href="item6.html">Seminovos</a></li>
		</ul>
	</nav>
</header>