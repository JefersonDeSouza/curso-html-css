<meta charset="UTF-8">
<meta name="viewport" content="width=device-width"><!--Definindo para browser de onde ele será pegar o width da tela-->
<link rel="stylesheet" type="text/css" href="fontes/webfonts/opensans_regular_macroman/stylesheet.css">
<link rel="stylesheet" type="text/css" href="css/reset.css">
<link rel="stylesheet" type="text/css" href="css/blog.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">