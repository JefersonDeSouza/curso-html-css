$(function() {
    $("#carrossel"). jCarouselLite({
        btnPrev: '.prev', 
        btnNext: '.next',
        visible: 1
    })
});