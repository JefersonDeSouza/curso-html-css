setInterval(TrocarBanner, 5000);
var banner = document.getElementById("Banner");
var pos = 0

function TrocarBanner()
{
	var arrayBanners = ["img11.jpg", "img12.jpg", "img13.jpg"];

	banner.src = "img/"+arrayBanners[pos];

	pos = (pos + 1) % arrayBanners.length;
}