//Trabalhando com variáveis

//var escola = "Caelum";
//console.info(escola, "Tipo da variável.: ",typeof escola);

//var idade = 10;
//console.log(idade, "Tipo da variável.: ",typeof idade);

//var certo = false;
//console.error(certo, "Tipo da variável.: ",typeof certo);

//var Nome = "Jeferson";
//console.warn(Nome, "Tipo da variável.: ",typeof Nome);

// array(LISTAS)
//var linguagens = ["html", "css", "javascript"];
//console.log(linguagens);
//console.dir(linguagens);//Logando uma informação com estrutura de diretório
//console.log(linguagens[2]);
/*
var output = document.getElementsByTagName('output')[0];

document.getElementById("#Tamanho").oninput = function(){
	output.value = this.value;
};*/

$("#Tamanho").on("input", function(){
	$("output").val($(this).val());
});
var $form = document.getElementsByTagName("form")[0];

var $busca = document.getElementById("txtBusca");

function ValidarForm()
{
	if($busca.value == "")
	{
		$busca.style.backgroundColor = "#f00";
		return false;
	}
	else
	{

		//$busca.style.backgroundColor = "#f00";	
	}
}

$form.onsubmit = ValidarForm;

setInterval(TrocarBanner, 900);
var banner = document.getElementById("Banner");
var pos = 0

function TrocarBanner()
{
	var arrayBanners = ["img11.jpg", "img12.jpg", "img13.jpg"];

	banner.src = "img/"+arrayBanners[pos];

	pos = (pos + 1) % arrayBanners.length;
}

/*trabalhando com contas matemáticas*/

var real = "R$ 9,99";

var sr = real.replace("R$ ","");

var sv = sr.replace(",",".");

var numero = sv.parseFloat(2);

console.log(realSoNumeros);

