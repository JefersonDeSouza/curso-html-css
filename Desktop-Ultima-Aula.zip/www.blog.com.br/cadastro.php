<!DOCTYPE php>
<html>
	<head>
		<title></title>
		<?php include("includes/head.php") ?>
	</head>
	<body>
		<div class="container">
			<main class="clearfix">
				<?php include("includes/cabecalho.php") ?>

				<?php include("includes/logo-rotacional.php") ?>
				
				<div class="jumbotron">Busca da Audi</div>

				<div class="panel panel-default">
					<header class="panel-heading">
						<h1 class="panel-title">
							Sua assinatura
						</h1>
					</header>
					
					<div class="panel-body">
						<div class="col-sm-4">
							<fieldset>
								<legend>Dados da Assinatura</legend>
							</fieldset>	
						</div>
						<form class="col-sm-8">
							<fieldset class="col-sm-6 col-lg-6">
								<legend>Dados Pessoais</legend>
								<div class="form-group">
									<label for="txtNome">Nome</label>
									<input class="form-control" type="text" id="txtNome" name="txtName">
								</div>

								<div class="form-group">
									<label for="txtEmai">Email</label>
									<input class="form-control" type="email" id="txtEmai" name="txtEmai">
								</div>

								<div class="form-group">
									<label for="rdSpam">
										<input class="form-control" type="checkbox" id="rdSpam" name="rdSpam">
									Spam</label>
								</div>
							</fieldset>

							<fieldset class="col-sm-6 col-lg-6">
								<legend>Dados do Cartão</legend>
								<div class="form-group">
									<label for="txtCartao">Catão</label>
									<input class="form-control" pattern="\d{2}\.\d{3}" placeholder="00.00" type="number" id="txtCartao" name="txtCartao">
								</div>

								<div class="form-group">
									<label for="selBandeira">Bandeira</label>
									<select class="form-control" id="selBandeira" name="selBandeira">
										<option value="0">Selecione a Bandeira</option>
										<option value="1">Visa</option>
										<option value="2">Master</option>
									</select>
								</div>

								<div class="form-group">
									<label for="txtVencimento">Vencimento</label>
									<input class="form-control" type="month" id="txtVencimento" name="txtVencimento">
								</div>


								<div class="form-group">
									<input class="form-control btn-primary" type="submit" id="btnEnviar" name="btnEnviar" value="Cadastrar">
								</div>
							</fieldset>
						</form>
					</div>
				</div>

				<!--<?php include("includes/conteudo-blog.php") ?>
				
				<?php include("includes/sidebar.php") ?>-->

				<?php include("includes/rodape.php") ?>
			</div>
		</div>

		<script type="text/javascript" src="js/jquery-1.12.1.min.js"></script>
		<script type="text/javascript" src="js/blog.js"></script>
		<script type="text/javascript" src="js/lab.js"></script>
	</body>
</html>