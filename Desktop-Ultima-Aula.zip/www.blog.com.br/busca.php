<!DOCTYPE php>
<html>
	<head>
		<title></title>
		<?php include("includes/head.php") ?>
	</head>
	<body>
		<div class="container">
			<main class="clearfix">
				<?php include("includes/cabecalho.php") ?>

				<?php include("includes/logo-rotacional.php") ?>
				
				<div class="jumbotron">Busca da Audi</div>

				<div class="panel panel-default">
					<header class="panel-heading">
						<h1 class="panel-title">
							Sua Busca.: <?php echo $_POST["txtBuscaBlog"] ?>
						</h1>
					</header>
					
					<div class="panel-body">
						<h2>Post 1</h2>
						<h3>Post 2</h3>
					</div>
				</div>

				<!--<?php include("includes/conteudo-blog.php") ?>
				
				<?php include("includes/sidebar.php") ?>-->

				<?php include("includes/rodape.php") ?>
			</div>
		</div>

		<script type="text/javascript" src="js/jquery-1.12.1.min.js"></script>
		<script type="text/javascript" src="js/blog.js"></script>
		<script type="text/javascript" src="js/lab.js"></script>
	</body>
</html>