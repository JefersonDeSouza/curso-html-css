function ExibirMsg()
{ 
    alert("Ta ai");
}